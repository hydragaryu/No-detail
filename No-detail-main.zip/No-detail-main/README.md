Delete immediatle if it wont dissapear
